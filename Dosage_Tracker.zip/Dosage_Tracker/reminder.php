<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">

 <title>Document</title>
</head>
<body>
<?php include "menu.php"; ?>
<?php require_once "connect.php"; ?>

                
                <?php
                    if(isset($_SESSION['message'])): ?>

                    <?php
                     echo $_SESSION['message'];
                     unset ($_SESSION['message']);
                     ?>
                <?php endif ?>
               



<?php  
    $mysqli = new mysqli('localhost','root','usbw','medicine') or die(mysqli_error($mysqli));
    $res = $mysqli->query("SELECT * FROM DOSE") or die($mysqli->error);
    ?>

 <!-- Main Content Section Starts -->
 <div class="main">
  
                <h1>Medication Reminder</h1>

                <table class="tbl-full">
                   <thead>
                   <tr>
                        <th>Medicine Name</th>
                        <th>Dosage</th>
                        <th>Miligram</th>
                        <th>Frequency</th>



                    </tr>
 
                   </thead>
                 
                    <?php 
                      while ($row = $res->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo $row ['medicine_name'];?></td>
                        <td><?php echo $row ['dosage'];?></td>
                        <td><?php echo $row ['miligram'];?></td>
                        <td><?php echo $row ['frequency'];?></td>
                     

                        </tr>
                        <?php endwhile ?>

                      
                </table>

                <?php
    function pre_r($array){
        echo '<pre>';
        print_r($array);
        echo '</pre>';
    }

    ?>
           

 

</body>
</html>