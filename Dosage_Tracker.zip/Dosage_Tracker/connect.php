<?php
session_start();

?>

<?php
$mysqli = new mysqli('localhost','root','usbw','medicine') or die(mysqli_error($mysqli));

$medicine_name = '';
$dosage = '';
$miligram = '';
$frequency = '';




if(isset($_POST['save']))
{
    // Button Clicked
    //echo "Button Clicked";

    //1. Get the Data from form
    $medicine_name = $_POST['medicine_name'];
    $dosage = $_POST['dosage'];
    $miligram = $_POST['miligram'];
    $frequency = $_POST['frequency'];

    $mysqli->query("INSERT INTO dose (medicine_name,dosage,miligram,frequency) VALUES('$medicine_name','$dosage','$miligram','$frequency');");


    $_SESSION['message'] = " Dosage has been saved";
    $_SESSION['msg_type'] = "success";

    header("Location: dosage.php");

}




if(isset($_POST['save_dose']))
{
    // Button Clicked
    //echo "Button Clicked";

    //1. Get the Data from form
    $medicine_name = $_POST['medicine_name'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $mysqli->query("INSERT INTO med_log (medicine_name,date,time) VALUES('$medicine_name','$date','$time');");


    $_SESSION['message'] = " Medicine taken has been saved";
    $_SESSION['msg_type'] = "success";

    header("Location: medication.php");

}



if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $mysqli->query("DELETE FROM dose WHERE id=$id") or die($mysqli->error());

    $_SESSION['message'] = " Dosage has been deleted";
    $_SESSION['msg_type'] = "error";

    header("Location: dosage.php");


}

?>