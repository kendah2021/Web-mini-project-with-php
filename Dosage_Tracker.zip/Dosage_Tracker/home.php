<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php include "menu.php"; ?>
     
     <div class="wrapper">
     <h1>Hello, <?php echo $_SESSION['name']; ?> welcome to Dosage Tracker</h1>
     <a href="logout.php" class="ca">Logout</a>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>