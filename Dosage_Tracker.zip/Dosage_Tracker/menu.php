<nav class="nav-bar">
     
     <ul>
         <li><a href="home.php">Home</a></li>
         <li><a href="dosage.php">Dosage</a></li>
         <li><a href="medication.php">Medication</a></li>
         <li><a href="reminder.php">Notifications</a></li>


     </ul>
</nav>
<hr>