<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="style.css">

 <title>Document</title>
</head>
<body>
<?php include "menu.php"; ?>
<?php require_once "connect.php"; ?>


                <h1>Dosage Form</h1>

                <?php
                    if(isset($_SESSION['message'])): ?>

                    <?php
                     echo $_SESSION['message'];
                     unset ($_SESSION['message']);
                     ?>
                <?php endif ?>
               
<form action="connect.php" method="POST">

    
            <input type="text" name="medicine_name" value="<?php echo $medicine_name; ?>" placeholder="Medicine Name" class="sec_input">
        
            <input type="text" name="dosage" value="<?php echo $dosage; ?>" placeholder="Dosage" class="sec_input">
            <input type="text" name="miligram" value="<?php echo $miligram; ?>" placeholder="Miligram" class="sec_input">
      
            <input type="text" name="frequency" value="<?php echo $frequency; ?>" placeholder="Frequency" class="sec_input">
       
 

    <tr>
        <td colspan="2">
            <input type="submit" name="save" value="Add Medicine" class="btn-secondary">
        </td>
    </tr>


</form>


<?php  
    $mysqli = new mysqli('localhost','root','usbw','medicine') or die(mysqli_error($mysqli));
    $res = $mysqli->query("SELECT * FROM DOSE") or die($mysqli->error);
    ?>


            
                <h1>Dosage Table</h1>

              

                <table class="tbl-full">
                   <thead>
                   <tr>
                        <th>Medicine Name</th>
                        <th>Dosage</th>
                        <th>Miligram</th>
                        <th>Frequency</th>
                        <th>Actions</th>



                    </tr>
 
                   </thead>
                 
                    <?php 
                      while ($row = $res->fetch_assoc()):
                    ?>
                    <tr>
                        <td><?php echo $row ['medicine_name'];?></td>
                        <td><?php echo $row ['dosage'];?></td>
                        <td><?php echo $row ['miligram'];?></td>
                        <td><?php echo $row ['frequency'];?></td>
                        <td>
                            
                            <a href="connect.php?delete=<?php echo $row ['id']; ?>"
                            class="btn btn-danger" >Delete</a>
                    </td>


                        </tr>
                        <?php endwhile ?>

                      
                </table>

                <?php
    function pre_r($array){
        echo '<pre>';
        print_r($array);
        echo '</pre>';
    }

    ?>
           

   

</body>
</html>